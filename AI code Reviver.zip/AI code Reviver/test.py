def sum():
    return a+b